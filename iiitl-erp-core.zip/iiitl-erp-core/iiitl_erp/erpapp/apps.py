from django.apps import AppConfig


class ErpappConfig(AppConfig):
    name = 'erpapp'
